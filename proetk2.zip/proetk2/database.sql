CREATE DATABASE IF NOT EXISTS moy_ne_sam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moy_ne_sam;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    service_type ENUM(
        'общий клининг',
        'генеральная уборка',
        'послестроительная уборка',
        'химчистка ковров и мебели'
    ) NOT NULL,
    preferred_date DATE NOT NULL,
    preferred_time TIME NOT NULL,
    payment_type ENUM('наличные', 'банковская карта') NOT NULL,
    status ENUM('новая', 'в работе', 'выполнено', 'отменено') DEFAULT 'новая',
    cancel_reason TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
