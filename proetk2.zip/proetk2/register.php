<?php
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($login === '' || $password === '' || $full_name === '' || $phone === '' || $email === '') {
        $error = 'Все поля обязательны для заполнения.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Укажите корректный адрес электронной почты.';
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT id FROM users WHERE login = ?');
        $stmt->execute([$login]);

        if ($stmt->fetch()) {
            $error = 'Пользователь с таким логином уже существует.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare(
                'INSERT INTO users (login, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([$login, $hash, $full_name, $phone, $email]);
            $success = 'Регистрация прошла успешно! Теперь вы можете войти в систему.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация — Мой Не Сам</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="hero">
        <h1>Мой Не Сам</h1>
        <p>Портал клининговых услуг</p>
    </div>

    <div class="page page--narrow">
        <div class="card card--register">
            <h2 class="card__title">Регистрация</h2>
            <p class="card__subtitle">Создайте аккаунт для оформления заявок на уборку</p>

            <?php if ($error): ?>
                <div class="alert alert--error"><?= escape($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert--success"><?= escape($success) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="login">Логин</label>
                    <input type="text" id="login" name="login" required
                           value="<?= escape($_POST['login'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="full_name">ФИО</label>
                    <input type="text" id="full_name" name="full_name" required
                           value="<?= escape($_POST['full_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="phone">Телефон</label>
                    <input type="tel" id="phone" name="phone" required
                           placeholder="+7 (___) ___-__-__"
                           value="<?= escape($_POST['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="email">Электронная почта</label>
                    <input type="email" id="email" name="email" required
                           value="<?= escape($_POST['email'] ?? '') ?>">
                </div>
                <button type="submit" class="btn btn--primary">Зарегистрироваться</button>
            </form>

            <p class="auth-footer">Уже есть аккаунт? <a href="login.php">Войти</a></p>
        </div>
    </div>
</body>
</html>
