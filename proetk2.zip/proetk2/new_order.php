<?php
require_once 'config.php';
requireLogin();

if (isAdmin()) {
    header('Location: admin/index.php');
    exit;
}

$db = getDB();
$stmt = $db->prepare('SELECT phone, email FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$error = '';
$success = '';

$services = [
    'общий клининг',
    'генеральная уборка',
    'послестроительная уборка',
    'химчистка ковров и мебели',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = trim($_POST['address'] ?? '');
    $contact_phone = trim($_POST['contact_phone'] ?? '');
    $service_type = $_POST['service_type'] ?? '';
    $preferred_date = $_POST['preferred_date'] ?? '';
    $preferred_time = $_POST['preferred_time'] ?? '';
    $payment_type = $_POST['payment_type'] ?? '';

    if ($address === '' || $contact_phone === '' || $service_type === '' ||
        $preferred_date === '' || $preferred_time === '' || $payment_type === '') {
        $error = 'Все поля обязательны для заполнения.';
    } elseif (!in_array($service_type, $services, true)) {
        $error = 'Выберите вид услуги из списка.';
    } elseif (!in_array($payment_type, ['наличные', 'банковская карта'], true)) {
        $error = 'Выберите тип оплаты.';
    } else {
        $stmt = $db->prepare(
            'INSERT INTO orders (user_id, address, contact_phone, service_type, preferred_date, preferred_time, payment_type)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $_SESSION['user_id'],
            $address,
            $contact_phone,
            $service_type,
            $preferred_date,
            $preferred_time,
            $payment_type,
        ]);
        header('Location: orders.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка — Мой Не Сам</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="site-header">
        <span class="site-header__logo">Мой Не Сам</span>
        <span class="site-header__user"><a href="orders.php">← Мои заявки</a></span>
    </header>

    <div class="page page--narrow">
        <div class="card card--form">
            <h2 class="card__title">Новая заявка</h2>
            <p class="card__subtitle">Укажите данные для оказания клининговой услуги</p>

            <?php if ($error): ?>
                <div class="alert alert--error"><?= escape($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="address">Адрес</label>
                    <input type="text" id="address" name="address" required
                           placeholder="г. Москва, ул. Примерная, д. 1, кв. 10"
                           value="<?= escape($_POST['address'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="contact_phone">Контактный телефон</label>
                    <input type="tel" id="contact_phone" name="contact_phone" required
                           value="<?= escape($_POST['contact_phone'] ?? $user['phone']) ?>">
                </div>
                <div class="form-group">
                    <label for="service_type">Вид услуги</label>
                    <select id="service_type" name="service_type" required>
                        <option value="">— Выберите услугу —</option>
                        <?php foreach ($services as $service): ?>
                            <option value="<?= escape($service) ?>"
                                <?= ($_POST['service_type'] ?? '') === $service ? 'selected' : '' ?>>
                                <?= escape($service) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="preferred_date">Желаемая дата</label>
                        <input type="date" id="preferred_date" name="preferred_date" required
                               min="<?= date('Y-m-d') ?>"
                               value="<?= escape($_POST['preferred_date'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="preferred_time">Желаемое время</label>
                        <input type="time" id="preferred_time" name="preferred_time" required
                               value="<?= escape($_POST['preferred_time'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="payment_type">Тип оплаты</label>
                    <select id="payment_type" name="payment_type" required>
                        <option value="">— Выберите способ оплаты —</option>
                        <option value="наличные" <?= ($_POST['payment_type'] ?? '') === 'наличные' ? 'selected' : '' ?>>Наличные</option>
                        <option value="банковская карта" <?= ($_POST['payment_type'] ?? '') === 'банковская карта' ? 'selected' : '' ?>>Банковская карта</option>
                    </select>
                </div>
                <button type="submit" class="btn btn--primary">Отправить заявку</button>
            </form>
        </div>
    </div>
</body>
</html>
