<?php
require_once 'config.php';
requireLogin();

if (isAdmin()) {
    header('Location: admin/index.php');
    exit;
}

$db = getDB();
$stmt = $db->prepare(
    'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC'
);
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

function statusBadge(string $status): string
{
    $map = [
        'новая' => ['badge--new', 'Новая'],
        'в работе' => ['badge--progress', 'В работе'],
        'выполнено' => ['badge--done', 'Выполнено'],
        'отменено' => ['badge--cancel', 'Отменено'],
    ];
    [$class, $label] = $map[$status] ?? ['badge--new', $status];
    return '<span class="badge ' . $class . '">' . escape($label) . '</span>';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заявки — Мой Не Сам</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="site-header">
        <span class="site-header__logo">Мой Не Сам</span>
        <span class="site-header__user"><?= escape($_SESSION['user_name']) ?> · <a href="logout.php">Выйти</a></span>
    </header>

    <div class="page">
        <div class="card card--orders">
            <div class="orders-toolbar">
                <div>
                    <h2 class="card__title">Мои заявки</h2>
                    <p class="card__subtitle" style="margin-bottom:0">История заказов на клининг</p>
                </div>
                <a href="new_order.php" class="btn btn--primary" style="width:auto">+ Новая заявка</a>
            </div>

            <?php if (empty($orders)): ?>
                <div class="empty-state">
                    <p>У вас пока нет заявок.</p>
                    <p style="margin-top:12px"><a href="new_order.php">Оформить первую заявку</a></p>
                </div>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-item">
                        <div class="order-item__header">
                            <span class="order-item__id">Заявка №<?= $order['id'] ?></span>
                            <?= statusBadge($order['status']) ?>
                        </div>
                        <div class="order-item__details">
                            <span><strong>Услуга:</strong> <?= escape($order['service_type']) ?></span>
                            <span><strong>Адрес:</strong> <?= escape($order['address']) ?></span>
                            <span><strong>Контакт:</strong> <?= escape($order['contact_phone']) ?></span>
                            <span><strong>Дата и время:</strong> <?= date('d.m.Y', strtotime($order['preferred_date'])) ?> в <?= date('H:i', strtotime($order['preferred_time'])) ?></span>
                            <span><strong>Оплата:</strong> <?= escape($order['payment_type']) ?></span>
                            <?php if ($order['status'] === 'отменено' && $order['cancel_reason']): ?>
                                <span style="color:var(--danger)"><strong>Причина отмены:</strong> <?= escape($order['cancel_reason']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="order-item__meta" style="margin-top:8px">
                            Создана: <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
