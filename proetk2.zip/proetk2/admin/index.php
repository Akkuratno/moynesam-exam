<?php
require_once '../config.php';
requireAdmin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $cancel_reason = trim($_POST['cancel_reason'] ?? '');

    $allowed = ['в работе', 'выполнено', 'отменено'];

    if ($order_id > 0 && in_array($status, $allowed, true)) {
        if ($status === 'отменено' && $cancel_reason === '') {
            $_SESSION['admin_error'] = 'При отмене заявки необходимо указать причину.';
        } else {
            $reason = $status === 'отменено' ? $cancel_reason : null;
            $stmt = $db->prepare('UPDATE orders SET status = ?, cancel_reason = ? WHERE id = ?');
            $stmt->execute([$status, $reason, $order_id]);
            $_SESSION['admin_success'] = 'Статус заявки №' . $order_id . ' обновлён.';
        }
    }
    header('Location: index.php');
    exit;
}

$stmt = $db->query(
    'SELECT o.*, u.full_name, u.email
     FROM orders o
     JOIN users u ON o.user_id = u.id
     ORDER BY o.created_at DESC'
);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

$error = $_SESSION['admin_error'] ?? '';
$success = $_SESSION['admin_success'] ?? '';
unset($_SESSION['admin_error'], $_SESSION['admin_success']);

function adminBadge(string $status): string
{
    $map = [
        'новая' => 'badge--new',
        'в работе' => 'badge--progress',
        'выполнено' => 'badge--done',
        'отменено' => 'badge--cancel',
    ];
    $class = $map[$status] ?? 'badge--new';
    return '<span class="badge ' . $class . '">' . escape($status) . '</span>';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора — Мой Не Сам</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="site-header">
        <span class="site-header__logo">Мой Не Сам · Админ</span>
        <span class="site-header__user"><a href="../logout.php">Выйти</a></span>
    </header>

    <div class="page">
        <div class="card card--admin">
            <h2 class="card__title">Панель администратора</h2>
            <p class="card__subtitle">Управление заявками заказчиков</p>

            <?php if ($error): ?>
                <div class="alert alert--error"><?= escape($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert--success"><?= escape($success) ?></div>
            <?php endif; ?>

            <?php if (empty($orders)): ?>
                <div class="empty-state"><p>Заявок пока нет.</p></div>
            <?php else: ?>
                <div class="admin-table-wrap">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>№</th>
                                <th>Заявитель</th>
                                <th>Контакты</th>
                                <th>Услуга</th>
                                <th>Адрес</th>
                                <th>Дата/время</th>
                                <th>Оплата</th>
                                <th>Статус</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?= $order['id'] ?></td>
                                    <td><?= escape($order['full_name']) ?></td>
                                    <td>
                                        <?= escape($order['contact_phone']) ?><br>
                                        <small><?= escape($order['email']) ?></small>
                                    </td>
                                    <td><?= escape($order['service_type']) ?></td>
                                    <td><?= escape($order['address']) ?></td>
                                    <td>
                                        <?= date('d.m.Y', strtotime($order['preferred_date'])) ?><br>
                                        <?= date('H:i', strtotime($order['preferred_time'])) ?>
                                    </td>
                                    <td><?= escape($order['payment_type']) ?></td>
                                    <td>
                                        <?= adminBadge($order['status']) ?>
                                        <?php if ($order['cancel_reason']): ?>
                                            <br><small style="color:var(--danger)"><?= escape($order['cancel_reason']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($order['status'] !== 'выполнено' && $order['status'] !== 'отменено'): ?>
                                            <form method="POST" class="admin-actions" data-order="<?= $order['id'] ?>">
                                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                                <select name="status" class="status-select" required>
                                                    <option value="">Сменить статус</option>
                                                    <?php if ($order['status'] === 'новая'): ?>
                                                        <option value="в работе">В работе</option>
                                                    <?php endif; ?>
                                                    <option value="выполнено">Выполнено</option>
                                                    <option value="отменено">Отменено</option>
                                                </select>
                                                <textarea name="cancel_reason" class="cancel-reason"
                                                          placeholder="Причина отмены (обязательно)"></textarea>
                                                <button type="submit" class="btn btn--sm btn--secondary">Применить</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="color:var(--muted);font-size:0.8rem">Закрыта</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.querySelectorAll('.status-select').forEach(function(select) {
        select.addEventListener('change', function() {
            var textarea = this.closest('form').querySelector('.cancel-reason');
            if (this.value === 'отменено') {
                textarea.classList.add('visible');
                textarea.required = true;
            } else {
                textarea.classList.remove('visible');
                textarea.required = false;
            }
        });
    });
    </script>
</body>
</html>
