<?php
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? 'admin/index.php' : 'orders.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($login === '' || $password === '') {
        $error = 'Введите логин и пароль.';
    } elseif ($login === ADMIN_LOGIN && $password === ADMIN_PASSWORD) {
        $_SESSION['is_admin'] = true;
        $_SESSION['user_name'] = 'Администратор';
        header('Location: admin/index.php');
        exit;
    } else {
        $db = getDB();
        $stmt = $db->prepare('SELECT id, password, full_name FROM users WHERE login = ?');
        $stmt->execute([$login]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['is_admin'] = false;
            header('Location: orders.php');
            exit;
        } else {
            $error = 'Неверный логин или пароль. Проверьте введённые данные.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Мой Не Сам</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="hero">
        <h1>Мой Не Сам</h1>
        <p>Портал клининговых услуг</p>
    </div>

    <div class="page page--narrow">
        <div class="card card--auth">
            <h2 class="card__title">Вход в систему</h2>
            <p class="card__subtitle">Введите логин и пароль для доступа к заявкам</p>

            <?php if ($error): ?>
                <div class="alert alert--error"><?= escape($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="login">Логин</label>
                    <input type="text" id="login" name="login" required
                           value="<?= escape($_POST['login'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn--primary">Войти</button>
            </form>

            <p class="auth-footer">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
        </div>
    </div>
</body>
</html>
