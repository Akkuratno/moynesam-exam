<?php
require_once __DIR__ . '/includes/auth.php';

if (current_user()) {
    header('Location: ' . (current_user()['role'] === 'admin' ? 'admin.php' : 'requests.php'));
    exit;
}

$error = null;
$success = $_SESSION['flash_success'] ?? null;
unset($_SESSION['flash_success']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->execute([$login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'login' => $user['login'],
            'full_name' => $user['full_name'],
            'role' => $user['role'],
        ];
        header('Location: ' . ($user['role'] === 'admin' ? 'admin.php' : 'requests.php'));
        exit;
    }
    $error = 'Неверный логин или пароль.';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Вход — Мой Не Сам</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
    <div class="logo">🧹 Мой Не Сам</div>
    <nav><a href="register.php">Нет аккаунта? Зарегистрироваться</a></nav>
</div>

<div class="split-screen">
    <div class="promo">
        <h2>Доверьте уборку профессионалам</h2>
        <ul>
            <li>Общий клининг и генеральная уборка</li>
            <li>Послестроительная уборка</li>
            <li>Химчистка ковров и мебели</li>
            <li>Оплата наличными или картой</li>
        </ul>
    </div>
    <div class="form-side">
        <div class="form-box">
            <h1>Вход в систему</h1>
            <?php if ($error): ?><div class="flash error"><?= h($error) ?></div><?php endif; ?>
            <?php if ($success): ?><div class="flash success"><?= h($success) ?></div><?php endif; ?>
            <form method="post" novalidate>
                <div class="field">
                    <label for="login">Логин</label>
                    <input type="text" id="login" name="login" required autofocus>
                </div>
                <div class="field">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" style="width:100%;">Войти</button>
            </form>
            <p class="muted" style="margin-top:14px;">Администратор: логин <b>adminka</b>.</p>
        </div>
    </div>
</div>
</body>
</html>
