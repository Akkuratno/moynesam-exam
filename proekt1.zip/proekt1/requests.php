<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$user = current_user();

$stmt = $pdo->prepare('SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([$user['id']]);
$rows = $stmt->fetchAll();

$counts = ['Новая' => 0, 'Подтверждена' => 0, 'Услуга оказана' => 0, 'Услуга отменена' => 0];
foreach ($rows as $r) { $counts[$r['status']] = ($counts[$r['status']] ?? 0) + 1; }

function status_badge($status) {
    $map = [
        'Новая' => 'badge-new',
        'Подтверждена' => 'badge-confirmed',
        'Услуга оказана' => 'badge-done',
        'Услуга отменена' => 'badge-rejected',
    ];
    $cls = $map[$status] ?? 'badge-new';
    return '<span class="badge ' . $cls . '">' . h($status) . '</span>';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Мои заявки — Мой Не Сам</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
    <div class="logo">🧹 Мой Не Сам</div>
    <nav>
        <span style="opacity:.85;">👤 <?= h($user['full_name']) ?></span>
        <a href="logout.php">Выйти</a>
    </nav>
</div>

<div class="dashboard">
    <div class="dashboard-head">
        <h1 style="margin:0;">История заявок</h1>
        <a class="btn" href="new_request.php">+ Новая заявка</a>
    </div>

    <div class="stat-row">
        <div class="stat-card"><div class="num"><?= (int)$counts['Новая'] ?></div><div class="lbl">Новые</div></div>
        <div class="stat-card"><div class="num"><?= (int)$counts['Подтверждена'] ?></div><div class="lbl">Подтверждены</div></div>
        <div class="stat-card"><div class="num"><?= (int)$counts['Услуга оказана'] ?></div><div class="lbl">Оказаны</div></div>
        <div class="stat-card"><div class="num"><?= (int)$counts['Услуга отменена'] ?></div><div class="lbl">Отменены</div></div>
    </div>

    <?php if (!$rows): ?>
        <div class="empty-state">
            У вас пока нет заявок.<br><br>
            <a class="btn" href="new_request.php">Оставить первую заявку</a>
        </div>
    <?php else: ?>
        <table class="requests-table">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Услуга</th>
                    <th>Адрес</th>
                    <th>Дата / время</th>
                    <th>Оплата</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= (int)$r['id'] ?></td>
                    <td><?= h($r['service_type']) ?></td>
                    <td><?= h($r['address']) ?></td>
                    <td><?= h(date('d.m.Y', strtotime($r['service_date']))) ?>, <?= h(substr($r['service_time'], 0, 5)) ?></td>
                    <td><?= h($r['payment_type']) ?></td>
                    <td>
                        <?= status_badge($r['status']) ?>
                        <?php if ($r['status'] === 'Услуга отменена' && $r['reject_reason']): ?>
                            <div class="reject-reason">Причина: <?= h($r['reject_reason']) ?></div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
