<?php
require_once __DIR__ . '/includes/auth.php';

$user = current_user();
if ($user) {
    header('Location: ' . ($user['role'] === 'admin' ? 'admin.php' : 'requests.php'));
} else {
    header('Location: login.php');
}
exit;
