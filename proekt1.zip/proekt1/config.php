<?php
// Параметры подключения к БД (стандартные для локального сервера XAMPP)
define('DB_HOST', 'localhost');
define('DB_NAME', 'moy_ne_sam');
define('DB_USER', 'root');
define('DB_PASS', '');

session_start();
