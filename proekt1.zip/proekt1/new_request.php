<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$user = current_user();

$services = ['Общий клининг', 'Генеральная уборка', 'Послестроительная уборка', 'Химчистка ковров и мебели'];
$errors = [];
$v = ['address' => '', 'contact_phone' => '', 'service_type' => '', 'service_date' => '', 'service_time' => '', 'payment_type' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $key => $_) { $v[$key] = trim($_POST[$key] ?? ''); }

    if ($v['address'] === '' || $v['contact_phone'] === '' || $v['service_date'] === '' || $v['service_time'] === '') {
        $errors[] = 'Заполните адрес, контактный телефон, дату и время.';
    }
    if (!in_array($v['service_type'], $services, true)) {
        $errors[] = 'Выберите вид услуги из списка.';
    }
    if (!in_array($v['payment_type'], ['Наличные', 'Банковская карта'], true)) {
        $errors[] = 'Выберите тип оплаты.';
    }
    if ($v['service_date'] !== '' && $v['service_date'] < date('Y-m-d')) {
        $errors[] = 'Дата получения услуги не может быть в прошлом.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO requests (user_id, address, contact_phone, service_type, service_date, service_time, payment_type, status)
                                VALUES (?, ?, ?, ?, ?, ?, ?, "Новая")');
        $stmt->execute([$user['id'], $v['address'], $v['contact_phone'], $v['service_type'], $v['service_date'], $v['service_time'], $v['payment_type']]);
        header('Location: requests.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Новая заявка — Мой Не Сам</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
    <div class="logo">🧹 Мой Не Сам</div>
    <nav>
        <a href="requests.php">← Мои заявки</a>
        <a href="logout.php">Выйти</a>
    </nav>
</div>

<div class="wizard">
    <h1>Формирование заявки</h1>
    <div class="sub">Заполните данные — мы подтвердим заявку в ближайшее время.</div>

    <?php if ($errors): ?>
    <div class="flash error"><?= implode('<br>', array_map('h', $errors)) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="wizard-step">
            <h3><span class="step-no">1</span>Адрес и контакты</h3>
            <div class="field" style="margin-top:14px;">
                <label for="address">Адрес помещения</label>
                <input type="text" id="address" name="address" value="<?= h($v['address']) ?>" placeholder="Город, улица, дом, квартира" required>
            </div>
            <div class="field">
                <label for="contact_phone">Контактный телефон</label>
                <input type="text" id="contact_phone" name="contact_phone" value="<?= h($v['contact_phone']) ?>" placeholder="+7 (___) ___-__-__" required>
            </div>
        </div>

        <div class="wizard-step">
            <h3><span class="step-no">2</span>Вид услуги</h3>
            <div class="service-grid">
                <?php foreach ($services as $s): ?>
                <label class="service-option">
                    <input type="radio" name="service_type" value="<?= h($s) ?>" <?= $v['service_type'] === $s ? 'checked' : '' ?> required>
                    <?= h($s) ?>
                </label>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="wizard-step">
            <h3><span class="step-no">3</span>Дата и время</h3>
            <div class="row2" style="margin-top:14px;">
                <div class="field">
                    <label for="service_date">Желаемая дата</label>
                    <input type="date" id="service_date" name="service_date" value="<?= h($v['service_date']) ?>" min="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="field">
                    <label for="service_time">Желаемое время</label>
                    <input type="time" id="service_time" name="service_time" value="<?= h($v['service_time']) ?>" required>
                </div>
            </div>
        </div>

        <div class="wizard-step">
            <h3><span class="step-no">4</span>Способ оплаты</h3>
            <div class="pay-grid">
                <label><input type="radio" name="payment_type" value="Наличные" <?= $v['payment_type'] === 'Наличные' ? 'checked' : '' ?> required> 💵 Наличные</label>
                <label><input type="radio" name="payment_type" value="Банковская карта" <?= $v['payment_type'] === 'Банковская карта' ? 'checked' : '' ?> required> 💳 Банковская карта</label>
            </div>
        </div>

        <button type="submit">Отправить заявку</button>
    </form>
</div>
</body>
</html>
