<?php
require_once __DIR__ . '/includes/auth.php';

if (current_user()) {
    header('Location: requests.php');
    exit;
}

$errors = [];
$values = ['login' => '', 'full_name' => '', 'phone' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($values as $key => $_) {
        $values[$key] = trim($_POST[$key] ?? '');
    }
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($values['login'] === '' || $values['full_name'] === '' || $values['phone'] === '' || $values['email'] === '' || $password === '') {
        $errors[] = 'Все поля обязательны для заполнения.';
    }
    if (!preg_match('/^[A-Za-zА-Яа-яЁё0-9_\-]{3,50}$/u', $values['login'])) {
        $errors[] = 'Логин должен содержать от 3 до 50 символов (буквы, цифры, "_" и "-").';
    }
    if ($values['email'] !== '' && !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Указан некорректный адрес электронной почты.';
    }
    if (strlen($password) < 4) {
        $errors[] = 'Пароль должен содержать не менее 4 символов.';
    }
    if ($password !== $password2) {
        $errors[] = 'Пароли не совпадают.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE login = ?');
        $stmt->execute([$values['login']]);
        if ($stmt->fetch()) {
            $errors[] = 'Пользователь с таким логином уже зарегистрирован.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('INSERT INTO users (login, password, full_name, phone, email, role) VALUES (?, ?, ?, ?, ?, "client")');
        $stmt->execute([$values['login'], $hash, $values['full_name'], $values['phone'], $values['email']]);
        $_SESSION['flash_success'] = 'Регистрация успешна! Теперь вы можете войти в систему.';
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Регистрация — Мой Не Сам</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
    <div class="logo">🧹 Мой Не Сам</div>
    <nav><a href="login.php">Уже есть аккаунт? Войти</a></nav>
</div>

<?php if ($errors): ?>
<div class="flash error"><?= implode('<br>', array_map('h', $errors)) ?></div>
<?php endif; ?>

<div class="auth-card-wrap">
    <div class="auth-card">
        <h1>Регистрация заказчика</h1>
        <div class="sub">Создайте учётную запись, чтобы оставлять заявки на уборку.</div>
        <form method="post" novalidate>
            <div class="field">
                <label for="full_name">ФИО</label>
                <input type="text" id="full_name" name="full_name" value="<?= h($values['full_name']) ?>" required>
            </div>
            <div class="row2">
                <div class="field">
                    <label for="login">Логин</label>
                    <input type="text" id="login" name="login" value="<?= h($values['login']) ?>" required>
                </div>
                <div class="field">
                    <label for="phone">Телефон</label>
                    <input type="text" id="phone" name="phone" value="<?= h($values['phone']) ?>" placeholder="+7 (___) ___-__-__" required>
                </div>
            </div>
            <div class="field">
                <label for="email">Адрес электронной почты</label>
                <input type="email" id="email" name="email" value="<?= h($values['email']) ?>" required>
            </div>
            <div class="row2">
                <div class="field">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="field">
                    <label for="password2">Повторите пароль</label>
                    <input type="password" id="password2" name="password2" required>
                </div>
            </div>
            <button type="submit" style="width:100%;margin-top:6px;">Зарегистрироваться</button>
        </form>
    </div>
</div>
</body>
</html>
