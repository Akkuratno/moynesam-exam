<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

// --- Обработка действий администратора (подтвердить / выполнить / отклонить) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['request_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id > 0 && in_array($action, ['confirm', 'done', 'reject'], true)) {
        if ($action === 'confirm') {
            $pdo->prepare('UPDATE requests SET status = "Подтверждена", reject_reason = NULL WHERE id = ?')->execute([$id]);
        } elseif ($action === 'done') {
            $pdo->prepare('UPDATE requests SET status = "Услуга оказана", reject_reason = NULL WHERE id = ?')->execute([$id]);
        } elseif ($action === 'reject') {
            $reason = trim($_POST['reason'] ?? '');
            if ($reason === '') { $reason = 'Причина не указана'; }
            $pdo->prepare('UPDATE requests SET status = "Услуга отменена", reject_reason = ? WHERE id = ?')->execute([$reason, $id]);
        }
    }
    header('Location: admin.php' . (isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
    exit;
}

$statuses = ['Новая', 'Подтверждена', 'Услуга оказана', 'Услуга отменена'];
$filter = $_GET['status'] ?? '';

$sql = 'SELECT r.*, u.full_name, u.email AS user_email, u.phone AS user_phone, u.login
        FROM requests r JOIN users u ON u.id = r.user_id';
$params = [];
if (in_array($filter, $statuses, true)) {
    $sql .= ' WHERE r.status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY r.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

function status_badge2($status) {
    $map = [
        'Новая' => 'badge-new',
        'Подтверждена' => 'badge-confirmed',
        'Услуга оказана' => 'badge-done',
        'Услуга отменена' => 'badge-rejected',
    ];
    return '<span class="badge ' . ($map[$status] ?? 'badge-new') . '">' . h($status) . '</span>';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Панель администратора — Мой Не Сам</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="topbar">
    <div class="logo">🧹 Мой Не Сам · Админ</div>
    <nav><a href="logout.php">Выйти</a></nav>
</div>

<div class="admin-wrap">
    <div class="dashboard-head">
        <h1 style="margin:0;">Все заявки</h1>
        <span class="muted">Всего: <?= count($rows) ?></span>
    </div>

    <div class="filter-tabs">
        <a href="admin.php" class="<?= $filter === '' ? 'active' : '' ?>">Все</a>
        <?php foreach ($statuses as $s): ?>
            <a href="admin.php?status=<?= urlencode($s) ?>" class="<?= $filter === $s ? 'active' : '' ?>"><?= h($s) ?></a>
        <?php endforeach; ?>
    </div>

    <?php if (!$rows): ?>
        <div class="empty-state">Заявок не найдено.</div>
    <?php else: ?>
    <div style="overflow-x:auto;">
    <table class="admin-table">
        <thead>
            <tr>
                <th>№</th>
                <th>Заказчик</th>
                <th>Контакты</th>
                <th>Услуга / адрес</th>
                <th>Дата / время</th>
                <th>Оплата</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td>#<?= (int)$r['id'] ?></td>
                <td><?= h($r['full_name']) ?><br><span class="muted">@<?= h($r['login']) ?></span></td>
                <td><?= h($r['contact_phone']) ?><br><span class="muted"><?= h($r['user_email']) ?></span></td>
                <td><?= h($r['service_type']) ?><br><span class="muted"><?= h($r['address']) ?></span></td>
                <td><?= h(date('d.m.Y', strtotime($r['service_date']))) ?><br><span class="muted"><?= h(substr($r['service_time'], 0, 5)) ?></span></td>
                <td><?= h($r['payment_type']) ?></td>
                <td>
                    <?= status_badge2($r['status']) ?>
                    <?php if ($r['status'] === 'Услуга отменена' && $r['reject_reason']): ?>
                        <div class="reject-reason"><?= h($r['reject_reason']) ?></div>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($r['status'] === 'Новая' || $r['status'] === 'Подтверждена'): ?>
                    <div class="actions-cell">
                        <?php if ($r['status'] === 'Новая'): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>">
                            <input type="hidden" name="action" value="confirm">
                            <button type="submit" class="btn-outline">Подтвердить</button>
                        </form>
                        <?php endif; ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>">
                            <input type="hidden" name="action" value="done">
                            <button type="submit">Оказана</button>
                        </form>
                        <form method="post" style="display:flex;gap:4px;margin-top:4px;">
                            <input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>">
                            <input type="hidden" name="action" value="reject">
                            <input type="text" name="reason" placeholder="Причина отклонения" style="font-size:.78rem;padding:6px 8px;">
                            <button type="submit" class="btn-danger">Отклонить</button>
                        </form>
                    </div>
                    <?php else: ?>
                        <span class="muted">—</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
