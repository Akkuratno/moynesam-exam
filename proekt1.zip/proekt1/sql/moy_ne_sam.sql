-- =====================================================================
-- Портал клининговых услуг "Мой Не Сам" — структура базы данных
-- СУБД: MySQL (XAMPP / phpMyAdmin)
-- Импорт: phpMyAdmin -> Импорт -> выбрать этот файл -> Запустить
-- =====================================================================

CREATE DATABASE IF NOT EXISTS moy_ne_sam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moy_ne_sam;

-- ---------------------------------------------------------------------
-- Пользователи (заказчики и администратор)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    login     VARCHAR(50)  NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone     VARCHAR(30)  NOT NULL,
    email     VARCHAR(120) NOT NULL,
    role      ENUM('client','admin') NOT NULL DEFAULT 'client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Заявки на клининговые услуги
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS requests (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    address       VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(30)  NOT NULL,
    service_type  ENUM(
        'Общий клининг',
        'Генеральная уборка',
        'Послестроительная уборка',
        'Химчистка ковров и мебели'
    ) NOT NULL,
    service_date  DATE NOT NULL,
    service_time  TIME NOT NULL,
    payment_type  ENUM('Наличные','Банковская карта') NOT NULL,
    status        ENUM('Новая','Подтверждена','Услуга оказана','Услуга отменена') NOT NULL DEFAULT 'Новая',
    reject_reason VARCHAR(255) NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_requests_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Учётная запись администратора: логин adminka / пароль password
-- (хэш ниже соответствует password_hash('password', PASSWORD_BCRYPT))
-- ---------------------------------------------------------------------
INSERT INTO users (login, password, full_name, phone, email, role)
VALUES (
    'adminka',
    '$2y$10$tm/rIERm3ANEtisGHfT3.uNpQBgYysfPDir6WmWBUOfMY5kRnc60u',
    'Администратор портала',
    '+7 (000) 000-00-00',
    'admin@moynesam.ru',
    'admin'
);

-- ---------------------------------------------------------------------
-- Пример клиента и заявки для проверки интерфейса (необязательно)
-- ---------------------------------------------------------------------
INSERT INTO users (login, password, full_name, phone, email, role)
VALUES (
    'ivanova',
    '$2y$10$tm/rIERm3ANEtisGHfT3.uNpQBgYysfPDir6WmWBUOfMY5kRnc60u',
    'Иванова Мария Сергеевна',
    '+7 (999) 123-45-67',
    'ivanova@example.com',
    'client'
);

INSERT INTO requests (user_id, address, contact_phone, service_type, service_date, service_time, payment_type, status)
VALUES (
    2,
    'г. Москва, ул. Ленина, д. 10, кв. 25',
    '+7 (999) 123-45-67',
    'Генеральная уборка',
    CURDATE() + INTERVAL 3 DAY,
    '14:00:00',
    'Банковская карта',
    'Новая'
);
