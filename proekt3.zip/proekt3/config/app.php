<?php
session_start();

define('ADMIN_LOGIN', 'adminka');
define('ADMIN_PASSWORD', 'password');

define('SERVICES', [
    'general' => 'Общий клининг',
    'deep' => 'Генеральная уборка',
    'post_construction' => 'Послестроительная уборка',
    'dry_cleaning' => 'Химчистка ковров и мебели',
]);

define('STATUS_LABELS', [
    'new' => 'Новая заявка',
    'in_progress' => 'В работе',
    'completed' => 'Услуга оказана',
    'cancelled' => 'Услуга отменена',
]);

define('PAYMENT_LABELS', [
    'cash' => 'Наличные',
    'card' => 'Банковская карта',
]);

function baseUrl(): string {
    static $base = null;
    if ($base === null) {
        $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
        if (basename($dir) === 'admin') {
            $dir = dirname($dir);
        }
        $base = ($dir === '/' || $dir === '\\') ? '' : $dir;
    }
    return $base;
}

function url(string $path = ''): string {
    return baseUrl() . $path;
}
