<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/layout.php';

if (isLoggedIn()) {
    redirect('/requests.php');
}

$errors = [];
$data = [
    'full_name' => '',
    'phone' => '',
    'email' => '',
    'login' => '',
    'password' => '',
];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'login' => trim($_POST['login'] ?? ''),
        'password' => $_POST['password'] ?? '',
    ];

    $errors = validateRegistration($data);

    if (empty($errors)) {
        $db = getDB();
        $stmt = $db->prepare('SELECT id FROM users WHERE login = ?');
        $stmt->execute([$data['login']]);
        if ($stmt->fetch()) {
            $errors['login'] = 'Этот логин уже занят';
        } else {
            $stmt = $db->prepare('INSERT INTO users (full_name, phone, email, login, password) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([
                $data['full_name'],
                $data['phone'],
                $data['email'],
                $data['login'],
                password_hash($data['password'], PASSWORD_DEFAULT),
            ]);
            $success = true;
        }
    }
}

renderHeader('Регистрация', 'page-register');
?>
<div class="hero">
    <span class="hero-icon">📝</span>
    <h1>Регистрация</h1>
    <p>Создайте аккаунт для подачи заявок</p>
</div>

<div class="card">
    <?php if ($success): ?>
        <div class="alert alert-success">Регистрация успешна! <a href="<?= url('/login.php') ?>">Войти</a></div>
    <?php else: ?>
    <form method="POST" novalidate>
        <?php
        $fields = [
            'full_name' => ['label' => 'ФИО', 'type' => 'text', 'placeholder' => 'Иванов Иван Иванович'],
            'phone' => ['label' => 'Телефон', 'type' => 'tel', 'placeholder' => '+7(999)-123-45-67', 'mask' => true],
            'email' => ['label' => 'Email', 'type' => 'email', 'placeholder' => 'user@mail.ru'],
            'login' => ['label' => 'Логин', 'type' => 'text', 'placeholder' => 'mylogin'],
            'password' => ['label' => 'Пароль', 'type' => 'password', 'placeholder' => 'Минимум 6 символов'],
        ];
        foreach ($fields as $name => $f):
        ?>
        <div class="form-group">
            <label for="<?= $name ?>"><?= $f['label'] ?></label>
            <input type="<?= $f['type'] ?>" id="<?= $name ?>" name="<?= $name ?>"
                   value="<?= e($data[$name]) ?>"
                   placeholder="<?= $f['placeholder'] ?? '' ?>"
                   class="<?= isset($errors[$name]) ? 'error' : '' ?>"
                   <?= !empty($f['mask']) ? 'data-phone-mask' : '' ?>
                   required>
            <?php if (isset($errors[$name])): ?>
                <div class="error-msg"><?= e($errors[$name]) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
    </form>
    <p class="form-link">Уже есть аккаунт? <a href="<?= url('/login.php') ?>">Войти</a></p>
    <?php endif; ?>
</div>
<?php renderFooter(); ?>
