<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/layout.php';

requireLogin();

$user = getCurrentUser();
$errors = [];
$success = false;

$data = [
    'address' => '',
    'contact_phone' => $user['phone'] ?? '',
    'service_type' => '',
    'custom_service' => '',
    'custom_service_check' => '',
    'desired_date' => '',
    'desired_time' => '',
    'payment_type' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'address' => trim($_POST['address'] ?? ''),
        'contact_phone' => trim($_POST['contact_phone'] ?? ''),
        'service_type' => $_POST['service_type'] ?? '',
        'custom_service' => trim($_POST['custom_service'] ?? ''),
        'custom_service_check' => $_POST['custom_service_check'] ?? '',
        'desired_date' => $_POST['desired_date'] ?? '',
        'desired_time' => $_POST['desired_time'] ?? '',
        'payment_type' => $_POST['payment_type'] ?? '',
    ];

    $errors = validateRequest($data);

    if (empty($errors)) {
        $serviceType = !empty($data['custom_service_check']) ? 'custom' : $data['service_type'];
        $customService = !empty($data['custom_service_check']) ? $data['custom_service'] : null;
        $datetime = $data['desired_date'] . ' ' . $data['desired_time'] . ':00';

        $db = getDB();
        $stmt = $db->prepare('
            INSERT INTO requests (user_id, address, contact_phone, service_type, custom_service, desired_datetime, payment_type)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ');
        $stmt->execute([
            $_SESSION['user_id'],
            $data['address'],
            $data['contact_phone'],
            $serviceType,
            $customService,
            $datetime,
            $data['payment_type'],
        ]);
        redirect('/requests.php');
    }
}

renderHeader('Новая заявка', 'page-create');
?>
<div class="hero">
    <span class="hero-icon">✨</span>
    <h1>Новая заявка</h1>
    <p>Заполните данные для заказа уборки</p>
</div>

<div class="card">
    <form method="POST" novalidate>
        <div class="form-group">
            <label for="address">Адрес</label>
            <input type="text" id="address" name="address" value="<?= e($data['address']) ?>"
                   placeholder="г. Москва, ул. Примерная, д. 1"
                   class="<?= isset($errors['address']) ? 'error' : '' ?>" required>
            <?php if (isset($errors['address'])): ?><div class="error-msg"><?= e($errors['address']) ?></div><?php endif; ?>
        </div>

        <div class="form-group">
            <label for="contact_phone">Контактный телефон</label>
            <input type="tel" id="contact_phone" name="contact_phone" value="<?= e($data['contact_phone']) ?>"
                   data-phone-mask class="<?= isset($errors['contact_phone']) ? 'error' : '' ?>" required>
            <?php if (isset($errors['contact_phone'])): ?><div class="error-msg"><?= e($errors['contact_phone']) ?></div><?php endif; ?>
        </div>

        <div class="form-group">
            <label>Вид услуги</label>
            <div class="service-list" id="service_list">
                <?php foreach (SERVICES as $key => $label): ?>
                <label class="service-option <?= $data['service_type'] === $key ? 'selected' : '' ?>">
                    <input type="radio" name="service_type" value="<?= $key ?>"
                           <?= $data['service_type'] === $key ? 'checked' : '' ?>>
                    <?= e($label) ?>
                </label>
                <?php endforeach; ?>
            </div>
            <?php if (isset($errors['service_type'])): ?><div class="error-msg"><?= e($errors['service_type']) ?></div><?php endif; ?>
        </div>

        <div class="checkbox-group">
            <input type="checkbox" id="custom_service_check" name="custom_service_check" value="1"
                   <?= $data['custom_service_check'] ? 'checked' : '' ?>>
            <label for="custom_service_check">Иная услуга</label>
        </div>

        <div class="form-group custom-service-field <?= $data['custom_service_check'] ? 'visible' : '' ?>" id="custom_service_field">
            <label for="custom_service">Опишите услугу</label>
            <textarea id="custom_service" name="custom_service" rows="3"
                      placeholder="Опишите, какая услуга вам нужна"
                      class="<?= isset($errors['custom_service']) ? 'error' : '' ?>"><?= e($data['custom_service']) ?></textarea>
            <?php if (isset($errors['custom_service'])): ?><div class="error-msg"><?= e($errors['custom_service']) ?></div><?php endif; ?>
        </div>

        <div class="form-group">
            <label for="desired_date">Желаемая дата</label>
            <input type="date" id="desired_date" name="desired_date" value="<?= e($data['desired_date']) ?>"
                   min="<?= date('Y-m-d') ?>"
                   class="<?= isset($errors['desired_date']) ? 'error' : '' ?>" required>
            <?php if (isset($errors['desired_date'])): ?><div class="error-msg"><?= e($errors['desired_date']) ?></div><?php endif; ?>
        </div>

        <div class="form-group">
            <label for="desired_time">Желаемое время</label>
            <input type="time" id="desired_time" name="desired_time" value="<?= e($data['desired_time']) ?>"
                   class="<?= isset($errors['desired_time']) ? 'error' : '' ?>" required>
            <?php if (isset($errors['desired_time'])): ?><div class="error-msg"><?= e($errors['desired_time']) ?></div><?php endif; ?>
        </div>

        <div class="form-group">
            <label for="payment_type">Тип оплаты</label>
            <select id="payment_type" name="payment_type"
                    class="<?= isset($errors['payment_type']) ? 'error' : '' ?>" required>
                <option value="">Выберите...</option>
                <option value="cash" <?= $data['payment_type'] === 'cash' ? 'selected' : '' ?>>Наличные</option>
                <option value="card" <?= $data['payment_type'] === 'card' ? 'selected' : '' ?>>Банковская карта</option>
            </select>
            <?php if (isset($errors['payment_type'])): ?><div class="error-msg"><?= e($errors['payment_type']) ?></div><?php endif; ?>
        </div>

        <div class="btn-group">
            <button type="submit" class="btn btn-primary">Отправить заявку</button>
            <a href="<?= url('/requests.php') ?>" class="btn btn-secondary">Назад</a>
        </div>
    </form>
</div>
<?php renderFooter(); ?>
