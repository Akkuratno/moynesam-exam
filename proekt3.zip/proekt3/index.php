<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    redirect('/requests.php');
} else {
    redirect('/login.php');
}
