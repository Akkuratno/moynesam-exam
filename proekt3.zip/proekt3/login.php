<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/layout.php';

if (isLoggedIn()) {
    redirect('/requests.php');
}

$error = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login) || empty($password)) {
        $error = 'Заполните все поля';
    } elseif (authenticateAdmin($login, $password)) {
        loginAdmin();
        redirect('/admin/');
    } else {
        $user = authenticateUser($login, $password);
        if ($user) {
            loginUser($user['id'], $user['login'], $user['full_name']);
            redirect('/requests.php');
        } else {
            $error = 'Неверный логин или пароль';
        }
    }
}

renderHeader('Вход', 'page-login');
?>
<div class="hero">
    <span class="hero-icon">🧹</span>
    <h1>Добро пожаловать</h1>
    <p>Войдите в портал клининговых услуг</p>
</div>

<div class="card">
    <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <div class="form-group">
            <label for="login">Логин</label>
            <input type="text" id="login" name="login" value="<?= e($login) ?>" required autocomplete="username">
        </div>
        <div class="form-group">
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>

    <p class="form-link">Нет аккаунта? <a href="<?= url('/register.php') ?>">Зарегистрироваться</a></p>
</div>
<?php renderFooter(); ?>
