<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../includes/auth.php';

if (isAdmin()) {
    redirect('/admin/');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if (authenticateAdmin($login, $password)) {
        loginAdmin();
        redirect('/admin/');
    } else {
        $error = 'Неверный логин или пароль администратора';
    }
}

require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/layout.php';
renderHeader('Админ-панель', 'page-admin');
?>
<div class="hero">
    <span class="hero-icon">🔐</span>
    <h1>Администратор</h1>
    <p>Вход в панель управления</p>
</div>

<div class="card">
    <?php if ($error): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="login">Логин</label>
            <input type="text" id="login" name="login" required autocomplete="username">
        </div>
        <div class="form-group">
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>

    <p class="form-link"><a href="<?= url('/login.php') ?>">← На главную</a></p>
</div>
<?php renderFooter(); ?>
