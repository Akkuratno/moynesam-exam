<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/layout.php';

requireAdmin();

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = (int)($_POST['request_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($requestId && in_array($action, ['in_progress', 'completed', 'cancelled'])) {
        if ($action === 'cancelled') {
            $reason = trim($_POST['cancellation_reason'] ?? '');
            if ($reason) {
                $stmt = $db->prepare('UPDATE requests SET status = ?, cancellation_reason = ? WHERE id = ?');
                $stmt->execute(['cancelled', $reason, $requestId]);
            }
        } else {
            $stmt = $db->prepare('UPDATE requests SET status = ?, cancellation_reason = NULL WHERE id = ?');
            $stmt->execute([$action, $requestId]);
        }
    }
    redirect('/admin/');
}

$requests = $db->query('
    SELECT r.*, u.full_name, u.email
    FROM requests r
    JOIN users u ON u.id = r.user_id
    ORDER BY r.created_at DESC
')->fetchAll();

$stats = [
    'new' => 0,
    'in_progress' => 0,
    'completed' => 0,
    'cancelled' => 0,
];
foreach ($requests as $r) {
    $stats[$r['status']]++;
}

renderHeader('Панель администратора', 'page-admin');
?>
<div class="hero">
    <span class="hero-icon">⚙️</span>
    <h1>Управление заявками</h1>
    <p>Всего заявок: <?= count($requests) ?></p>
</div>

<div class="admin-stats">
    <div class="stat-card">
        <div class="num"><?= $stats['new'] ?></div>
        <div class="label">Новые</div>
    </div>
    <div class="stat-card">
        <div class="num"><?= $stats['in_progress'] ?></div>
        <div class="label">В работе</div>
    </div>
    <div class="stat-card">
        <div class="num"><?= $stats['completed'] ?></div>
        <div class="label">Выполнено</div>
    </div>
    <div class="stat-card">
        <div class="num"><?= $stats['cancelled'] ?></div>
        <div class="label">Отменено</div>
    </div>
</div>

<?php if (empty($requests)): ?>
<div class="empty-state">
    <div class="icon">📭</div>
    <p>Заявок пока нет</p>
</div>
<?php else: ?>
<div class="request-list">
    <?php foreach ($requests as $r): ?>
    <div class="request-card status-<?= e($r['status']) ?>">
        <span class="status-badge"><?= e(STATUS_LABELS[$r['status']]) ?></span>
        <h3><?= e($r['full_name']) ?></h3>
        <div class="request-meta">
            <span>🧹 <?= e(getServiceLabel($r['service_type'], $r['custom_service'])) ?></span>
            <span>📍 <?= e($r['address']) ?></span>
            <span>📞 <?= e($r['contact_phone']) ?></span>
            <span>✉️ <?= e($r['email']) ?></span>
            <span>📅 <?= e(formatDateTime($r['desired_datetime'])) ?></span>
            <span>💳 <?= e(PAYMENT_LABELS[$r['payment_type']]) ?></span>
        </div>
        <?php if ($r['status'] === 'cancelled' && $r['cancellation_reason']): ?>
        <div class="cancellation-reason">Причина: <?= e($r['cancellation_reason']) ?></div>
        <?php endif; ?>

        <?php if ($r['status'] !== 'completed' && $r['status'] !== 'cancelled'): ?>
        <div class="admin-actions">
            <?php if ($r['status'] === 'new'): ?>
            <form method="POST" style="flex:1">
                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="action" value="in_progress">
                <button type="submit" class="btn btn-sm btn-primary" style="width:100%">В работе</button>
            </form>
            <?php endif; ?>
            <?php if ($r['status'] === 'in_progress' || $r['status'] === 'new'): ?>
            <form method="POST" style="flex:1">
                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="action" value="completed">
                <button type="submit" class="btn btn-sm btn-primary" style="width:100%">Выполнено</button>
            </form>
            <button type="button" class="btn btn-sm btn-danger" data-cancel-request="<?= $r['id'] ?>">Отменить</button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="modal-overlay" id="cancel_modal">
    <div class="modal">
        <h3>Отмена заявки</h3>
        <form method="POST">
            <input type="hidden" name="request_id" id="cancel_request_id" value="">
            <input type="hidden" name="action" value="cancelled">
            <div class="form-group">
                <label for="cancellation_reason">Причина отмены *</label>
                <textarea id="cancellation_reason" name="cancellation_reason" rows="3" required
                          placeholder="Укажите причину отмены"></textarea>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-danger">Подтвердить отмену</button>
                <button type="button" class="btn btn-secondary" data-close-modal>Закрыть</button>
            </div>
        </form>
    </div>
</div>

<div class="btn-group" style="margin-top:24px">
    <a href="<?= url('/admin/logout.php') ?>" class="btn btn-secondary btn-sm">Выйти</a>
</div>
<?php renderFooter(); ?>
