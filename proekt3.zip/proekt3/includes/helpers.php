<?php
require_once __DIR__ . '/../config/app.php';

function validateFullName(string $name): ?string {
    if (!preg_match('/^[А-ЯЁа-яё\s\-]+$/u', $name)) {
        return 'ФИО должно содержать только кириллицу и пробелы';
    }
    if (mb_strlen(trim($name)) < 3) {
        return 'ФИО слишком короткое';
    }
    return null;
}

function validatePhone(string $phone): ?string {
    if (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        return 'Телефон в формате +7(XXX)-XXX-XX-XX';
    }
    return null;
}

function validateEmail(string $email): ?string {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return 'Некорректный адрес электронной почты';
    }
    return null;
}

function validateLogin(string $login): ?string {
    if (strlen($login) < 3) {
        return 'Логин минимум 3 символа';
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) {
        return 'Логин: только латиница, цифры и _';
    }
    return null;
}

function validatePassword(string $password): ?string {
    if (strlen($password) < 6) {
        return 'Пароль минимум 6 символов';
    }
    return null;
}

function validateRegistration(array $data): array {
    $errors = [];
    $fields = ['full_name', 'phone', 'email', 'login', 'password'];

    foreach ($fields as $field) {
        if (empty(trim($data[$field] ?? ''))) {
            $errors[$field] = 'Обязательное поле';
        }
    }

    if (empty($errors['full_name']) && ($e = validateFullName($data['full_name']))) $errors['full_name'] = $e;
    if (empty($errors['phone']) && ($e = validatePhone($data['phone']))) $errors['phone'] = $e;
    if (empty($errors['email']) && ($e = validateEmail($data['email']))) $errors['email'] = $e;
    if (empty($errors['login']) && ($e = validateLogin($data['login']))) $errors['login'] = $e;
    if (empty($errors['password']) && ($e = validatePassword($data['password']))) $errors['password'] = $e;

    return $errors;
}

function validateRequest(array $data): array {
    $errors = [];

    foreach (['address', 'contact_phone', 'desired_date', 'desired_time', 'payment_type'] as $field) {
        if (empty(trim($data[$field] ?? ''))) {
            $errors[$field] = 'Обязательное поле';
        }
    }

    $isCustom = !empty($data['custom_service_check']);
    if ($isCustom) {
        if (empty(trim($data['custom_service'] ?? ''))) {
            $errors['custom_service'] = 'Опишите требуемую услугу';
        }
    } else {
        if (empty($data['service_type'])) {
            $errors['service_type'] = 'Выберите вид услуги';
        }
    }

    if (empty($errors['contact_phone']) && ($e = validatePhone($data['contact_phone']))) {
        $errors['contact_phone'] = $e;
    }

    return $errors;
}

function getServiceLabel(string $type, ?string $custom = null): string {
    if ($type === 'custom' && $custom) {
        return 'Иная услуга: ' . $custom;
    }
    return SERVICES[$type] ?? $type;
}

function redirect(string $path): void {
    header('Location: ' . url($path));
    exit;
}

function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

function formatDateTime(string $dt): string {
    return date('d.m.Y H:i', strtotime($dt));
}
