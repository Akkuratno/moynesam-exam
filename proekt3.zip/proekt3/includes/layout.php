<?php
function renderHeader(string $title, string $pageClass = ''): void {
    $userName = $_SESSION['user_name'] ?? '';
    $isAdmin = isAdmin();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title><?= e($title) ?> — Мой Не Сам</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= url('/assets/css/style.css') ?>">
</head>
<body class="<?= e($pageClass) ?>">
    <div class="app-shell">
        <header class="site-header">
            <a href="<?= url($isAdmin ? '/admin/' : (isLoggedIn() ? '/requests.php' : '/login.php')) ?>" class="logo">
                <span class="logo-icon">✦</span>
                <span class="logo-text">Мой Не Сам</span>
            </a>
            <?php if ($userName || $isAdmin): ?>
            <div class="header-user">
                <?php if ($isAdmin): ?>
                    <span class="badge-admin">Админ</span>
                <?php else: ?>
                    <span class="user-greeting"><?= e(mb_substr($userName, 0, 1)) ?>.</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </header>
        <main class="main-content">
<?php
}

function renderFooter(): void {
?>
        </main>
        <footer class="site-footer">
            <p>© 2026 Портал клининговых услуг</p>
        </footer>
    </div>
    <script src="<?= url('/assets/js/app.js') ?>"></script>
</body>
</html>
<?php
}
