<?php
require_once __DIR__ . '/../config/database.php';

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function isAdmin(): bool {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        redirect('/login.php');
    }
}

function requireAdmin(): void {
    if (!isAdmin()) {
        redirect('/admin/login.php');
    }
}

function loginUser(int $userId, string $login, string $fullName): void {
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_login'] = $login;
    $_SESSION['user_name'] = $fullName;
    $_SESSION['is_admin'] = false;
}

function loginAdmin(): void {
    $_SESSION['is_admin'] = true;
    $_SESSION['user_login'] = ADMIN_LOGIN;
    unset($_SESSION['user_id'], $_SESSION['user_name']);
}

function logout(): void {
    session_destroy();
    session_start();
}

function getCurrentUser(): ?array {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function authenticateUser(string $login, string $password): ?array {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->execute([$login]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        return $user;
    }
    return null;
}

function authenticateAdmin(string $login, string $password): bool {
    return $login === ADMIN_LOGIN && $password === ADMIN_PASSWORD;
}
