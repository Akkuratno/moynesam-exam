<?php
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/layout.php';

requireLogin();

$db = getDB();
$stmt = $db->prepare('
    SELECT r.*, u.full_name
    FROM requests r
    JOIN users u ON u.id = r.user_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
');
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();

renderHeader('Мои заявки', 'page-requests');
?>
<div class="hero">
    <span class="hero-icon">📋</span>
    <h1>Мои заявки</h1>
    <p>История и статус ваших заказов</p>
</div>

<?php if (empty($requests)): ?>
<div class="empty-state">
    <div class="icon">📭</div>
    <p>У вас пока нет заявок</p>
    <p style="margin-top:8px;font-size:0.85rem">Создайте первую заявку на уборку</p>
</div>
<?php else: ?>
<div class="request-list">
    <?php foreach ($requests as $r): ?>
    <div class="request-card status-<?= e($r['status']) ?>">
        <span class="status-badge"><?= e(STATUS_LABELS[$r['status']]) ?></span>
        <h3><?= e(getServiceLabel($r['service_type'], $r['custom_service'])) ?></h3>
        <div class="request-meta">
            <span>📍 <?= e($r['address']) ?></span>
            <span>📅 <?= e(formatDateTime($r['desired_datetime'])) ?></span>
            <span>💳 <?= e(PAYMENT_LABELS[$r['payment_type']]) ?></span>
            <span>📞 <?= e($r['contact_phone']) ?></span>
        </div>
        <?php if ($r['status'] === 'cancelled' && $r['cancellation_reason']): ?>
        <div class="cancellation-reason">
            Причина отмены: <?= e($r['cancellation_reason']) ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<a href="<?= url('/create_request.php') ?>" class="fab" title="Новая заявка">+</a>

<div class="btn-group" style="margin-top:24px">
    <a href="<?= url('/logout.php') ?>" class="btn btn-secondary btn-sm">Выйти</a>
</div>
<?php renderFooter(); ?>
