document.addEventListener('DOMContentLoaded', () => {
    initPhoneMask();
    initCustomService();
    initServiceSelection();
    initAdminModal();
});

function initPhoneMask() {
    document.querySelectorAll('[data-phone-mask]').forEach(input => {
        input.addEventListener('input', (e) => {
            let val = e.target.value.replace(/\D/g, '');
            if (val.startsWith('8')) val = '7' + val.slice(1);
            if (!val.startsWith('7')) val = '7' + val;
            val = val.slice(0, 11);

            let formatted = '+7';
            if (val.length > 1) formatted += '(' + val.slice(1, 4);
            if (val.length >= 4) formatted += ')-' + val.slice(4, 7);
            if (val.length >= 7) formatted += '-' + val.slice(7, 9);
            if (val.length >= 9) formatted += '-' + val.slice(9, 11);

            e.target.value = formatted;
        });
    });
}

function initCustomService() {
    const checkbox = document.getElementById('custom_service_check');
    const field = document.getElementById('custom_service_field');
    const serviceList = document.getElementById('service_list');

    if (!checkbox || !field) return;

    checkbox.addEventListener('change', () => {
        field.classList.toggle('visible', checkbox.checked);
        if (serviceList) {
            serviceList.style.display = checkbox.checked ? 'none' : 'flex';
            if (checkbox.checked) {
                serviceList.querySelectorAll('input').forEach(r => r.checked = false);
            }
        }
    });

    if (checkbox.checked) {
        field.classList.add('visible');
        if (serviceList) serviceList.style.display = 'none';
    }
}

function initServiceSelection() {
    document.querySelectorAll('.service-option').forEach(option => {
        option.addEventListener('click', () => {
            document.querySelectorAll('.service-option').forEach(o => o.classList.remove('selected'));
            option.classList.add('selected');
            const radio = option.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        });
    });
}

function initAdminModal() {
    const overlay = document.getElementById('cancel_modal');
    if (!overlay) return;

    document.querySelectorAll('[data-cancel-request]').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('cancel_request_id').value = btn.dataset.cancelRequest;
            overlay.classList.add('active');
        });
    });

    overlay.querySelector('[data-close-modal]')?.addEventListener('click', () => {
        overlay.classList.remove('active');
    });

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.classList.remove('active');
    });
}
